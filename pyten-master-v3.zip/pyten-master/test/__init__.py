from pyten.tenclass import *
from pyten.tools import *
from pyten.method import *

